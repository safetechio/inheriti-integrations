Sample archive listing only.
